import torch
import torch.nn as nn
import torch.nn.functional as F
import cv2
import numpy as np
from torchvision import transforms
from PIL import Image


class CNNModel(nn.Module):
    def __init__(self):
        super(CNNModel, self).__init__()

        self.conv1 = nn.Conv2d(in_channels=3, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(in_channels=32, out_channels=128, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, stride=1, padding=1)

        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)

        self.fc1 = nn.Linear(128 *128*128, 128) 
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, 63)
        self.leaky_relu = nn.LeakyReLU(negative_slope=0.01)
        self.dropout = nn.Dropout(p=0.5)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = self.pool(F.relu(self.conv2(x)))
        x = self.pool(F.relu(self.conv3(x)))

        x = x.view(-1, 128 * 64 * 64) 
        x = self.leaky_relu(self.fc1(x))
        x = self.dropout(x)
        x = self.leaky_relu(self.fc2(x))
        output = self.fc3(x)
        return output

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNNModel().to(device)
model.load_state_dict(torch.load('model_weights5789.pth'))
model.eval()

transform = transforms.Compose([
    transforms.Resize((256, 256)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
])

class Button:
    def __init__(self, pos, text, size):
        self.pos = pos
        self.text = text
        self.size = size

    def draw_button(self, frame):
        overlay = frame.copy()
        top_left = self.pos
        bottom_right = (self.pos[0] + self.size[0], self.pos[1] + self.size[1])
        cv2.rectangle(overlay, top_left, bottom_right, (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.5, frame, 0.5, 0, frame)
        cv2.rectangle(frame, top_left, bottom_right, (255, 255, 0), 2)
        text_size = cv2.getTextSize(self.text, cv2.FONT_HERSHEY_SIMPLEX, 1, 2)[0]
        text_x = self.pos[0] + (self.size[0] - text_size[0]) // 2
        text_y = self.pos[1] + (self.size[1] + text_size[1]) // 2
        cv2.putText(frame, self.text, (text_x, text_y), cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 0), 2)

def draw_keyboard_on_frame(frame):
    keys = [['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
            ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 'Ent'],
            ['Z', 'X', 'C', 'V', 'B', 'N', 'M', '?', '!', 'Del'],
            ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0']]
    key_size = (80, 60)
    start_x, start_y = 200, 450
    key_objects = []
    
    for row_num, row in enumerate(keys):
        for col_num, key in enumerate(row):
            x = start_x + col_num * (key_size[0] + 10)
            y = start_y + row_num * (key_size[1] + 10)
            btn = Button((x, y), key, key_size)
            btn.draw_button(frame)
            key_objects.append(btn)
    return key_objects

def predict_landmarks(frame):
    img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
    img = transform(img).unsqueeze(0).to(device)
    with torch.no_grad():
        landmarks = model(img).cpu().numpy().reshape(21, 3)
    return landmarks

def draw_landmarks(frame, landmarks):
    for landmark in landmarks:
        x = int(landmark[0] * frame.shape[1])  
        y = int(landmark[1] * frame.shape[0])  
        cv2.circle(frame, (x, y), 5, (0, 255, 0), -1) 

def check_fingertip_on_key(fingertips, keys):
    for tip in fingertips:
        x, y = int(tip[0]), int(tip[1])
        for key in keys:
            key_x, key_y = key.pos
            key_w, key_h = key.size
            if key_x < x < key_x + key_w and key_y < y < key_y + key_h:
                return key.text  
    return None

def display_text_bar(frame, text):
    bar_position = (100, 100)
    bar_size = (1080, 80)
    cv2.rectangle(frame, bar_position, (bar_position[0] + bar_size[0], bar_position[1] + bar_size[1]), (50, 50, 50), -1)
    cv2.putText(frame, text, (bar_position[0] + 10, bar_position[1] + 55), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 3)

fingertip_indices = [8, 12, 16, 20]

cap = cv2.VideoCapture(0)
cap.set(3, 1280)
cap.set(4, 720)

typed_text = ""

while True:
    ret, frame = cap.read()
    frame = cv2.flip(frame, 1)

    landmarks = predict_landmarks(frame)

    fingertips = [(landmarks[i][0] * frame.shape[1], landmarks[i][1] * frame.shape[0]) for i in fingertip_indices]

    keys = draw_keyboard_on_frame(frame)

    pressed_key = check_fingertip_on_key(fingertips, keys)
    if pressed_key:
        if pressed_key == "Del":
            typed_text = typed_text[:-1]
        elif pressed_key != "Ent":
            typed_text += pressed_key 
        print(f'Pressed key: {pressed_key}')

    display_text_bar(frame, typed_text)

    draw_landmarks(frame, landmarks)

    cv2.imshow("Virtual Keyboard with Camera Feed", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
