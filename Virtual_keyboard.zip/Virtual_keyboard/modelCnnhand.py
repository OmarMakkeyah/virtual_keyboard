                    
                                #by:
                                    #omar mohamed elsayed mekkia
                                    #mohamed mohamed elsayed mekkia
                                    #2nd year summer 2024


import os
import pandas as pd
from PIL import Image
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
import torch.optim as optim
import ast

# CNN Model
class CNNModel(nn.Module):
    def __init__(self):
        super(CNNModel, self).__init__()

        self.conv1 = nn.Conv2d(in_channels=3, out_channels=32, kernel_size=3, stride=1, padding=1)
        self.conv2 = nn.Conv2d(in_channels=32, out_channels=128, kernel_size=3, stride=1, padding=1)
        self.conv3 = nn.Conv2d(in_channels=128, out_channels=128, kernel_size=3, stride=1, padding=1)

        self.pool = nn.MaxPool2d(kernel_size=2, stride=2, padding=0)

        self.fc1 = nn.Linear(128 *128*128, 128)
        self.fc2 = nn.Linear(128, 128)
        self.fc3 = nn.Linear(128, 42) 
        self.leaky_relu = nn.LeakyReLU(negative_slope=0.01)
        self.dropout = nn.Dropout(p=0.5)

    def forward(self, x):
        x = F.relu(self.conv1(x))
        x = F.relu(self.conv2(x))
        x = self.pool(F.relu(self.conv3(x)))

        x = x.view(-1, 128 *128*128) 
        x = self.leaky_relu(self.fc1(x))
      
        x = self.leaky_relu(self.fc2(x))
        output = self.fc3(x)
        return output

class HandLandmarksDataset(Dataset):
    def __init__(self, csv_file, transform=None):
        self.data_frame = pd.read_csv(csv_file)
        self.transform = transform

    def __len__(self):
        return len(self.data_frame)

    def __getitem__(self, idx):
       img_path = self.data_frame.iloc[idx, 0]
       img = Image.open(img_path).convert('RGB')

       if self.transform:
           img = self.transform(img)

       landmarks = []
       for i in range(21):
           try:
               landmark_str = self.data_frame.iloc[idx, 2 + i]
               landmark = ast.literal_eval(landmark_str)

               if len(landmark) == 2:
                   landmarks.extend(landmark) 
               else:
                   raise ValueError(f"Landmark at index {idx} does not have 2 coordinates: {landmark}")

           except ValueError as e:
               print(f"Error converting landmark values at index {idx} for landmark {i}: {e}")
               raise

       labels = torch.tensor(landmarks, dtype=torch.float32)
       return img, labels 

def calculate_rmse(loader, model, device):
    model.eval()
    total_rmse = 0
    total_samples = 0
    all_outputs = []
    all_labels = []

    with torch.no_grad():
        for images, labels in loader:
            images = images.to(device)
            labels = labels.to(device)

            outputs_landmarks = model(images)

            mse = ((outputs_landmarks - labels) ** 2).mean()
            rmse = torch.sqrt(mse)
            total_rmse += rmse.item() * labels.size(0)
            total_samples += labels.size(0)

            all_outputs.append(outputs_landmarks)
            all_labels.append(labels)

    mean_rmse = total_rmse / total_samples

    all_outputs = torch.cat(all_outputs, dim=0)
    all_labels = torch.cat(all_labels, dim=0)

    mean_labels = all_labels.mean(dim=0)

    sst = torch.sum((all_labels - mean_labels) ** 2)

    sse = torch.sum((all_labels - all_outputs) ** 2)

    r_squared = 1 - (sse / sst)

    return mean_rmse, r_squared.item() 

if __name__ == '__main__':
    transform = transforms.Compose([
        transforms.Resize((256, 256)),  
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
    ])
    torch.manual_seed(20)

    csv_file_path = 'C:/Users/omarm/Downloads/hand_landmarks22nn.csv'
    dataset = HandLandmarksDataset(csv_file=csv_file_path, transform=transform)

    train_size = int(0.8 * len(dataset))
    val_size = len(dataset) - train_size
    train_dataset, val_dataset = torch.utils.data.random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True, drop_last=True)
    val_loader = DataLoader(val_dataset, batch_size=16, shuffle=False, drop_last=True)

    # Model, Loss, Optimizer
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = CNNModel().to(device)
    criterion = nn.MSELoss()  
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)

    patience = 3
    best_val_rmse = float('inf')
    epochs_no_improve = 0
    early_stop = False
    num_epochs = 100

    for epoch in range(num_epochs):
        model.train()
        running_loss = 0.0

        for images, labels in train_loader:
            images = images.to(device)
            labels = labels.to(device)

            optimizer.zero_grad()

            outputs_landmarks = model(images)

            loss = criterion(outputs_landmarks, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        
        scheduler.step()

        train_rmse, train_r2 = calculate_rmse(train_loader, model, device)
        val_rmse, val_r2 = calculate_rmse(val_loader, model, device)


        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {running_loss / len(train_loader):.4f}, '
              f'Training RMSE: {train_rmse:.4f}, Training R²: {train_r2:.4f}, '
              f'Validation RMSE: {val_rmse:.4f}, Validation R²: {val_r2:.4f}')

        if val_rmse < best_val_rmse:
            best_val_rmse = val_rmse
            epochs_no_improve = 0
            torch.save(model.state_dict(), 'model_weights5789.pth')
        else:
            epochs_no_improve += 1

        if epochs_no_improve >= patience:
            print("Early stopping triggered!")
            early_stop = True
            break

    if not early_stop:
        print("Training finished without early stopping.")
